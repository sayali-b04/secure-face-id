/**
 * FaceDetector Component
 * ----------------------
 * Webcam-based face detection with liveness verification.
 * Shows the camera feed, detection status, and liveness challenge.
 * Calls onVerified(capturedImage) when liveness is confirmed.
 */

import { useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useFaceDetection } from "@/hooks/useFaceDetection";
import { Camera, CheckCircle2, XCircle, Loader2, RefreshCw } from "lucide-react";

interface FaceDetectorProps {
  onVerified: (capturedImage: string) => void;
  onError?: (message: string) => void;
}

const FaceDetector = ({ onVerified, onError }: FaceDetectorProps) => {
  const {
    videoRef,
    canvasRef,
    modelsLoaded,
    faceDetected,
    livenessVerified,
    error,
    challenge,
    isDetecting,
    loadModels,
    startCamera,
    stopCamera,
    startDetection,
    captureFrame,
    reset,
  } = useFaceDetection();

  // Load models on mount
  useEffect(() => {
    loadModels();
  }, [loadModels]);

  // Report errors up
  useEffect(() => {
    if (error && onError) onError(error);
  }, [error, onError]);

  // Auto-capture when liveness is verified
  useEffect(() => {
    if (livenessVerified && faceDetected) {
      const img = captureFrame();
      if (img) {
        stopCamera();
        onVerified(img);
      }
    }
  }, [livenessVerified, faceDetected, captureFrame, stopCamera, onVerified]);

  // Start the camera + detection flow
  const handleStart = useCallback(async () => {
    reset();
    await startCamera();
    // Small delay for the video to initialize
    setTimeout(() => {
      startDetection();
    }, 500);
  }, [reset, startCamera, startDetection]);

  // Retry from scratch
  const handleRetry = useCallback(() => {
    stopCamera();
    reset();
  }, [stopCamera, reset]);

  const challengeText =
    challenge === "blink"
      ? "Please blink your eyes 2 times"
      : "Please slowly turn your head left or right";

  return (
    <Card className="border-border">
      <CardContent className="p-4 space-y-3">
        {/* Webcam feed */}
        <div className="relative rounded-md overflow-hidden bg-muted aspect-video flex items-center justify-center">
          <video
            ref={videoRef}
            autoPlay
            muted
            playsInline
            className={`w-full h-full object-cover ${isDetecting ? "block" : "hidden"}`}
          />
          {/* Hidden canvas for frame capture */}
          <canvas ref={canvasRef} className="hidden" />

          {!isDetecting && (
            <div className="flex flex-col items-center gap-2 text-muted-foreground">
              <Camera className="h-10 w-10" />
              <p className="text-sm">Camera preview</p>
            </div>
          )}

          {/* Status overlay */}
          {isDetecting && (
            <div className="absolute top-2 left-2 flex flex-col gap-1">
              <Badge variant={faceDetected ? "default" : "destructive"} className="text-xs">
                {faceDetected ? (
                  <><CheckCircle2 className="h-3 w-3 mr-1" /> Face Detected</>
                ) : (
                  <><XCircle className="h-3 w-3 mr-1" /> No Face</>
                )}
              </Badge>
              {faceDetected && !livenessVerified && (
                <Badge variant="secondary" className="text-xs">
                  <Loader2 className="h-3 w-3 mr-1 animate-spin" /> Checking liveness...
                </Badge>
              )}
              {livenessVerified && (
                <Badge className="text-xs bg-success text-success-foreground">
                  <CheckCircle2 className="h-3 w-3 mr-1" /> Liveness Verified!
                </Badge>
              )}
            </div>
          )}
        </div>

        {/* Challenge instruction */}
        {isDetecting && faceDetected && !livenessVerified && (
          <p className="text-sm text-center font-medium text-foreground">
            🎯 {challengeText}
          </p>
        )}

        {/* Loading models indicator */}
        {!modelsLoaded && (
          <p className="text-xs text-muted-foreground text-center flex items-center justify-center gap-1">
            <Loader2 className="h-3 w-3 animate-spin" /> Loading face detection models...
          </p>
        )}

        {/* Error message */}
        {error && (
          <p className="text-sm text-destructive text-center">{error}</p>
        )}

        {/* Action buttons */}
        <div className="flex gap-2 justify-center">
          {!isDetecting && !livenessVerified && (
            <Button
              type="button"
              onClick={handleStart}
              disabled={!modelsLoaded}
              size="sm"
            >
              <Camera className="h-4 w-4 mr-1" />
              {modelsLoaded ? "Start Face Verification" : "Loading..."}
            </Button>
          )}
          {(isDetecting || livenessVerified) && (
            <Button type="button" variant="outline" onClick={handleRetry} size="sm">
              <RefreshCw className="h-4 w-4 mr-1" /> Retry
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default FaceDetector;
