/**
 * useFaceDetection Hook
 * ---------------------
 * Handles face-api.js model loading, webcam face detection,
 * and basic liveness detection (blink / head movement).
 *
 * Rejects: objects, photos, AI images (via liveness challenge).
 * Returns: faceDetected, livenessVerified, capturedImage, error
 */

import { useState, useRef, useCallback, useEffect } from "react";
import * as faceapi from "face-api.js";

// face-api.js models hosted on a CDN
const MODEL_URL = "https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.12/model";

type LivenessChallenge = "blink" | "turn_head";

export function useFaceDetection() {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<number | null>(null);

  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [faceDetected, setFaceDetected] = useState(false);
  const [livenessVerified, setLivenessVerified] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [challenge, setChallenge] = useState<LivenessChallenge>("blink");
  const [isDetecting, setIsDetecting] = useState(false);

  // Track landmark history for liveness
  const landmarkHistory = useRef<{ leftEye: number; rightEye: number; noseX: number }[]>([]);

  // Load face-api.js models once
  const loadModels = useCallback(async () => {
    try {
      await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
        faceapi.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URL),
        faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
      ]);
      setModelsLoaded(true);
    } catch (err) {
      setError("Failed to load face detection models. Check your internet connection.");
      console.error("Model loading error:", err);
    }
  }, []);

  // Start webcam stream
  const startCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 480, height: 360, facingMode: "user" },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch {
      setError("Camera access denied. Please allow camera to proceed.");
    }
  }, []);

  // Stop webcam
  const stopCamera = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setIsDetecting(false);
  }, []);

  /**
   * Eye Aspect Ratio (EAR) — used for blink detection.
   * When the eye is closed, EAR drops significantly.
   */
  const getEAR = (eyePoints: faceapi.Point[]) => {
    const vertical1 = Math.hypot(eyePoints[1].x - eyePoints[5].x, eyePoints[1].y - eyePoints[5].y);
    const vertical2 = Math.hypot(eyePoints[2].x - eyePoints[4].x, eyePoints[2].y - eyePoints[4].y);
    const horizontal = Math.hypot(eyePoints[0].x - eyePoints[3].x, eyePoints[0].y - eyePoints[3].y);
    return (vertical1 + vertical2) / (2.0 * horizontal);
  };

  // Main detection loop
  const startDetection = useCallback(async () => {
    if (!modelsLoaded || !videoRef.current) return;

    // Randomly pick a challenge
    setChallenge(Math.random() > 0.5 ? "blink" : "turn_head");
    setLivenessVerified(false);
    setFaceDetected(false);
    setCapturedImage(null);
    setError(null);
    landmarkHistory.current = [];
    setIsDetecting(true);

    let blinkCount = 0;
    let prevEAR = 0.3;

    intervalRef.current = window.setInterval(async () => {
      if (!videoRef.current) return;

      // Detect a single face with landmarks
      const detection = await faceapi
        .detectSingleFace(videoRef.current, new faceapi.TinyFaceDetectorOptions({ scoreThreshold: 0.5 }))
        .withFaceLandmarks(true);

      if (!detection) {
        setFaceDetected(false);
        return;
      }

      setFaceDetected(true);

      // Get landmarks for liveness
      const landmarks = detection.landmarks;
      const leftEye = landmarks.getLeftEye();
      const rightEye = landmarks.getRightEye();
      const nose = landmarks.getNose();

      const leftEAR = getEAR(leftEye);
      const rightEAR = getEAR(rightEye);
      const avgEAR = (leftEAR + rightEAR) / 2;
      const noseX = nose[0].x;

      landmarkHistory.current.push({ leftEye: leftEAR, rightEye: rightEAR, noseX });

      // Keep only last 60 frames (~2 seconds at 30fps)
      if (landmarkHistory.current.length > 60) {
        landmarkHistory.current.shift();
      }

      if (challenge === "blink") {
        // Detect blink: EAR drops below 0.2 then recovers
        if (prevEAR > 0.22 && avgEAR < 0.19) {
          blinkCount++;
        }
        prevEAR = avgEAR;

        // Need at least 2 blinks for liveness
        if (blinkCount >= 2) {
          setLivenessVerified(true);
        }
      } else {
        // Detect head turn: nose X position shifts significantly
        const history = landmarkHistory.current;
        if (history.length >= 15) {
          const first = history[0].noseX;
          const last = history[history.length - 1].noseX;
          const diff = Math.abs(last - first);
          // If nose moved more than 30px, head turned
          if (diff > 30) {
            setLivenessVerified(true);
          }
        }
      }
    }, 200); // Check every 200ms
  }, [modelsLoaded, challenge]);

  // Capture the current frame as a base64 image
  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;

    const canvas = canvasRef.current;
    const video = videoRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d");
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
    setCapturedImage(dataUrl);
    return dataUrl;
  }, []);

  // Reset state for a new attempt
  const reset = useCallback(() => {
    setFaceDetected(false);
    setLivenessVerified(false);
    setCapturedImage(null);
    setError(null);
    landmarkHistory.current = [];
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  return {
    videoRef,
    canvasRef,
    modelsLoaded,
    faceDetected,
    livenessVerified,
    capturedImage,
    error,
    challenge,
    isDetecting,
    loadModels,
    startCamera,
    stopCamera,
    startDetection,
    captureFrame,
    reset,
  };
}
