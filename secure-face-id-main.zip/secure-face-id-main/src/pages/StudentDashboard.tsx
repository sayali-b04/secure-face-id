import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  User, Mail, Building2, Hash, GraduationCap, CalendarDays,
  ShieldCheck, ShieldX, Pencil, Plus, BookOpen, LogOut,
} from "lucide-react";

const API = "http://localhost:5000/api";

const YEARS = ["FE", "SE", "TE", "BE"] as const;

interface MarkEntry {
  year: string;
  subjects: string[];
  gpa: number;
}

interface StudentProfile {
  name: string;
  email: string;
  role: string;
  department: string;
  rollNumber: string;
  year: string;
  admissionYear: number | string;
  passoutYear: number | string;
  imageUrl: string;
  faceHash: string;
  marks: MarkEntry[];
}

const emptyProfile: StudentProfile = {
  name: "", email: "", role: "student", department: "", rollNumber: "",
  year: "", admissionYear: "", passoutYear: "", imageUrl: "", faceHash: "", marks: [],
};

/* ── helpers ── */
const getToken = () => localStorage.getItem("token") ?? "";

const authFetch = async (url: string, opts: RequestInit = {}) => {
  const res = await fetch(url, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}`, ...(opts.headers as Record<string, string>) },
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
};

/* ── component ── */
const StudentDashboard = () => {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<StudentProfile>(emptyProfile);
  const [loading, setLoading] = useState(true);

  // edit‑profile dialog
  const [editOpen, setEditOpen] = useState(false);
  const [editData, setEditData] = useState(emptyProfile);

  // add/edit marks dialog
  const [marksOpen, setMarksOpen] = useState(false);
  const [marksYear, setMarksYear] = useState("FE");
  const [marksSubjects, setMarksSubjects] = useState("");
  const [marksGpa, setMarksGpa] = useState("");

  /* ── fetch profile on mount ── */
  useEffect(() => {
    if (!getToken()) { navigate("/login"); return; }
    authFetch(`${API}/users/profile`)
      .then((data) => { setProfile(data); setLoading(false); })
      .catch(() => { toast.error("Session expired – please log in again"); navigate("/login"); });
  }, [navigate]);

  /* ── save profile edits ── */
  const handleSaveProfile = async () => {
    try {
      const updated = await authFetch(`${API}/users/profile`, {
        method: "PUT",
        body: JSON.stringify({
          name: editData.name,
          department: editData.department,
          rollNumber: editData.rollNumber,
          year: editData.year,
          admissionYear: editData.admissionYear,
          passoutYear: editData.passoutYear,
        }),
      });
      setProfile(updated);
      setEditOpen(false);
      toast.success("Profile updated");
    } catch { toast.error("Failed to update profile"); }
  };

  /* ── save marks ── */
  const handleSaveMarks = async () => {
    try {
      const updated = await authFetch(`${API}/users/marks`, {
        method: "PUT",
        body: JSON.stringify({
          year: marksYear,
          subjects: marksSubjects.split(",").map((s) => s.trim()).filter(Boolean),
          gpa: parseFloat(marksGpa),
        }),
      });
      setProfile(updated);
      setMarksOpen(false);
      toast.success("Marks saved");
    } catch { toast.error("Failed to save marks"); }
  };

  const openEditProfile = () => { setEditData(profile); setEditOpen(true); };

  const openMarksDialog = (yr?: string) => {
    const existing = profile.marks?.find((m) => m.year === yr);
    setMarksYear(yr ?? "FE");
    setMarksSubjects(existing?.subjects?.join(", ") ?? "");
    setMarksGpa(existing?.gpa?.toString() ?? "");
    setMarksOpen(true);
  };

  const handleLogout = () => { localStorage.removeItem("token"); navigate("/login"); };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-muted-foreground">Loading dashboard…</p>
      </div>
    );
  }

  const verified = !!profile.faceHash;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* ── header ── */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">Student Dashboard</h1>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => navigate("/profile-edit")}>
              <Pencil className="h-4 w-4 mr-1" /> Full Edit
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-1" /> Logout
            </Button>
          </div>
        </div>

        {/* ── profile card ── */}
        <Card>
          <CardHeader className="flex-row items-center gap-4 space-y-0">
            <Avatar className="h-20 w-20">
              <AvatarImage src={profile.imageUrl ? `${API.replace("/api", "")}/${profile.imageUrl}` : undefined} />
              <AvatarFallback className="text-xl">{profile.name?.charAt(0) ?? "S"}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <CardTitle className="text-xl">{profile.name}</CardTitle>
              <CardDescription>{profile.email}</CardDescription>
              <div className="mt-1">
                {verified
                  ? <Badge className="bg-success text-success-foreground"><ShieldCheck className="h-3 w-3 mr-1" /> Verified</Badge>
                  : <Badge variant="destructive"><ShieldX className="h-3 w-3 mr-1" /> Not Verified</Badge>}
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={openEditProfile}>
              <Pencil className="h-4 w-4 mr-1" /> Edit
            </Button>
          </CardHeader>

          <Separator />

          <CardContent className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <InfoRow icon={<Building2 className="h-4 w-4" />} label="Department" value={profile.department || "—"} />
            <InfoRow icon={<Hash className="h-4 w-4" />} label="Roll Number" value={profile.rollNumber || "—"} />
            <InfoRow icon={<GraduationCap className="h-4 w-4" />} label="Year" value={profile.year || "—"} />
            <InfoRow icon={<CalendarDays className="h-4 w-4" />} label="Admission Year" value={profile.admissionYear?.toString() || "—"} />
            <InfoRow icon={<CalendarDays className="h-4 w-4" />} label="Passout Year" value={profile.passoutYear?.toString() || "Currently Pursuing"} />
          </CardContent>
        </Card>

        {/* ── marks section ── */}
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-lg flex items-center gap-2">
              <BookOpen className="h-5 w-5" /> Academic Marks
            </CardTitle>
            <Button size="sm" onClick={() => openMarksDialog()}>
              <Plus className="h-4 w-4 mr-1" /> Add Marks
            </Button>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="FE">
              <TabsList className="grid grid-cols-4 w-full">
                {YEARS.map((y) => <TabsTrigger key={y} value={y}>{y}</TabsTrigger>)}
              </TabsList>

              {YEARS.map((y) => {
                const entry = profile.marks?.find((m) => m.year === y);
                return (
                  <TabsContent key={y} value={y}>
                    {entry ? (
                      <div className="space-y-3">
                        <Table>
                          <TableHeader>
                            <TableRow><TableHead>Subject</TableHead></TableRow>
                          </TableHeader>
                          <TableBody>
                            {entry.subjects.map((s, i) => (
                              <TableRow key={i}><TableCell>{s}</TableCell></TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <p className="text-sm text-muted-foreground">GPA: <span className="font-semibold text-foreground">{entry.gpa}</span></p>
                        <Button variant="outline" size="sm" onClick={() => openMarksDialog(y)}>
                          <Pencil className="h-3 w-3 mr-1" /> Update
                        </Button>
                      </div>
                    ) : (
                      <p className="text-muted-foreground text-sm py-4 text-center">
                        No marks recorded for {y}.{" "}
                        <button className="text-primary underline" onClick={() => openMarksDialog(y)}>Add now</button>
                      </p>
                    )}
                  </TabsContent>
                );
              })}
            </Tabs>
          </CardContent>
        </Card>
      </div>

      {/* ── Edit Profile Dialog ── */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
            <DialogDescription>Update your student information below.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Field label="Name" value={editData.name} onChange={(v) => setEditData({ ...editData, name: v })} />
            <Field label="Department" value={editData.department} onChange={(v) => setEditData({ ...editData, department: v })} />
            <Field label="Roll Number" value={editData.rollNumber} onChange={(v) => setEditData({ ...editData, rollNumber: v })} />
            <div className="space-y-1">
              <Label>Year</Label>
              <Select value={editData.year} onValueChange={(v) => setEditData({ ...editData, year: v })}>
                <SelectTrigger><SelectValue placeholder="Select year" /></SelectTrigger>
                <SelectContent>
                  {YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Field label="Admission Year" value={editData.admissionYear?.toString()} onChange={(v) => setEditData({ ...editData, admissionYear: v })} />
            <Field label="Passout Year" value={editData.passoutYear?.toString()} onChange={(v) => setEditData({ ...editData, passoutYear: v })} placeholder="Leave empty for Currently Pursuing" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveProfile}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── Marks Dialog ── */}
      <Dialog open={marksOpen} onOpenChange={setMarksOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add / Update Marks</DialogTitle>
            <DialogDescription>Enter subjects (comma‑separated) and GPA for the selected year.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Year</Label>
              <Select value={marksYear} onValueChange={setMarksYear}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Field label="Subjects (comma separated)" value={marksSubjects} onChange={setMarksSubjects} placeholder="Maths, Physics, Chemistry" />
            <Field label="GPA" value={marksGpa} onChange={setMarksGpa} placeholder="e.g. 8.5" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMarksOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveMarks}>Save Marks</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

/* ── small reusable pieces ── */
const InfoRow = ({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) => (
  <div className="flex items-center gap-2 text-foreground">
    <span className="text-muted-foreground">{icon}</span>
    <span className="text-muted-foreground">{label}:</span>
    <span className="font-medium">{value}</span>
  </div>
);

const Field = ({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) => (
  <div className="space-y-1">
    <Label>{label}</Label>
    <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
  </div>
);

export default StudentDashboard;
