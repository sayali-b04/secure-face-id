import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  Mail, Building2, CalendarDays, ShieldCheck, ShieldX,
  Pencil, Plus, BookOpen, LogOut, Users, X,
} from "lucide-react";

const API = "http://localhost:5000/api";
const getToken = () => localStorage.getItem("token") ?? "";

const authFetch = async (url: string, opts: RequestInit = {}) => {
  const res = await fetch(url, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}`, ...(opts.headers as Record<string, string>) },
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
};

interface TeacherProfile {
  name: string;
  email: string;
  role: string;
  department: string;
  joiningYear: number | string;
  subjects: string[];
  teachingYears: number | string;
  classesHandled: string[];
  imageUrl: string;
  faceHash: string;
}

const emptyProfile: TeacherProfile = {
  name: "", email: "", role: "teacher", department: "", joiningYear: "",
  subjects: [], teachingYears: "", classesHandled: [], imageUrl: "", faceHash: "",
};

const TeacherDashboard = () => {
  const navigate = useNavigate();
  const [profile, setProfile] = useState<TeacherProfile>(emptyProfile);
  const [loading, setLoading] = useState(true);

  /* edit profile dialog */
  const [editOpen, setEditOpen] = useState(false);
  const [editName, setEditName] = useState("");
  const [editDept, setEditDept] = useState("");
  const [editJoining, setEditJoining] = useState("");

  /* subjects dialog */
  const [subOpen, setSubOpen] = useState(false);
  const [subInput, setSubInput] = useState("");

  /* classes dialog */
  const [classOpen, setClassOpen] = useState(false);
  const [classInput, setClassInput] = useState("");

  /* fetch profile */
  useEffect(() => {
    if (!getToken()) { navigate("/login"); return; }
    authFetch(`${API}/users/profile`)
      .then((data) => { setProfile(data); setLoading(false); })
      .catch(() => { toast.error("Session expired"); navigate("/login"); });
  }, [navigate]);

  /* save profile */
  const handleSaveProfile = async () => {
    try {
      const updated = await authFetch(`${API}/users/profile`, {
        method: "PUT",
        body: JSON.stringify({ name: editName, department: editDept, joiningYear: editJoining }),
      });
      setProfile(updated);
      setEditOpen(false);
      toast.success("Profile updated");
    } catch { toast.error("Failed to update profile"); }
  };

  /* save subjects */
  const handleSaveSubjects = async () => {
    try {
      const subjects = subInput.split(",").map((s) => s.trim()).filter(Boolean);
      const updated = await authFetch(`${API}/users/profile`, {
        method: "PUT",
        body: JSON.stringify({ subjects }),
      });
      setProfile(updated);
      setSubOpen(false);
      toast.success("Subjects updated");
    } catch { toast.error("Failed to update subjects"); }
  };

  /* save classes */
  const handleSaveClasses = async () => {
    try {
      const classesHandled = classInput.split(",").map((s) => s.trim()).filter(Boolean);
      const updated = await authFetch(`${API}/users/profile`, {
        method: "PUT",
        body: JSON.stringify({ classesHandled }),
      });
      setProfile(updated);
      setClassOpen(false);
      toast.success("Classes updated");
    } catch { toast.error("Failed to update classes"); }
  };

  const openEdit = () => {
    setEditName(profile.name);
    setEditDept(profile.department);
    setEditJoining(profile.joiningYear?.toString() ?? "");
    setEditOpen(true);
  };

  const openSubjects = () => {
    setSubInput(profile.subjects?.join(", ") ?? "");
    setSubOpen(true);
  };

  const openClasses = () => {
    setClassInput(profile.classesHandled?.join(", ") ?? "");
    setClassOpen(true);
  };

  const handleLogout = () => { localStorage.removeItem("token"); navigate("/login"); };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-muted-foreground">Loading dashboard…</p>
      </div>
    );
  }

  const verified = !!profile.faceHash;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">

        {/* header */}
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-foreground">Teacher Dashboard</h1>
          <Button variant="outline" size="sm" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-1" /> Logout
          </Button>
        </div>

        {/* profile card */}
        <Card>
          <CardHeader className="flex-row items-center gap-4 space-y-0">
            <Avatar className="h-20 w-20">
              <AvatarImage src={profile.imageUrl ? `${API.replace("/api", "")}/${profile.imageUrl}` : undefined} />
              <AvatarFallback className="text-xl">{profile.name?.charAt(0) ?? "T"}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <CardTitle className="text-xl">{profile.name}</CardTitle>
              <CardDescription>{profile.email}</CardDescription>
              <div className="mt-1">
                {verified
                  ? <Badge className="bg-success text-success-foreground"><ShieldCheck className="h-3 w-3 mr-1" /> Verified</Badge>
                  : <Badge variant="destructive"><ShieldX className="h-3 w-3 mr-1" /> Not Verified</Badge>}
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={openEdit}>
              <Pencil className="h-4 w-4 mr-1" /> Edit
            </Button>
          </CardHeader>

          <Separator />

          <CardContent className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
            <InfoRow icon={<Building2 className="h-4 w-4" />} label="Department" value={profile.department || "—"} />
            <InfoRow icon={<CalendarDays className="h-4 w-4" />} label="Joining Year" value={profile.joiningYear?.toString() || "—"} />
            <InfoRow icon={<CalendarDays className="h-4 w-4" />} label="Teaching Years" value={profile.teachingYears?.toString() || "—"} />
          </CardContent>
        </Card>

        {/* subjects card */}
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-lg flex items-center gap-2">
              <BookOpen className="h-5 w-5" /> Subjects
            </CardTitle>
            <Button size="sm" onClick={openSubjects}>
              <Plus className="h-4 w-4 mr-1" /> Update Subjects
            </Button>
          </CardHeader>
          <CardContent>
            {profile.subjects?.length ? (
              <div className="flex flex-wrap gap-2">
                {profile.subjects.map((s, i) => (
                  <Badge key={i} variant="secondary">{s}</Badge>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">No subjects added yet.</p>
            )}
          </CardContent>
        </Card>

        {/* classes card */}
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="h-5 w-5" /> Classes Handled
            </CardTitle>
            <Button size="sm" onClick={openClasses}>
              <Plus className="h-4 w-4 mr-1" /> Update Classes
            </Button>
          </CardHeader>
          <CardContent>
            {profile.classesHandled?.length ? (
              <div className="flex flex-wrap gap-2">
                {profile.classesHandled.map((c, i) => (
                  <Badge key={i} variant="outline">{c}</Badge>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">No classes added yet.</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Edit Profile Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
            <DialogDescription>Update your teacher profile information.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1"><Label>Name</Label><Input value={editName} onChange={(e) => setEditName(e.target.value)} /></div>
            <div className="space-y-1"><Label>Department</Label><Input value={editDept} onChange={(e) => setEditDept(e.target.value)} /></div>
            <div className="space-y-1"><Label>Joining Year</Label><Input value={editJoining} onChange={(e) => setEditJoining(e.target.value)} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveProfile}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Subjects Dialog */}
      <Dialog open={subOpen} onOpenChange={setSubOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Subjects</DialogTitle>
            <DialogDescription>Enter subjects separated by commas.</DialogDescription>
          </DialogHeader>
          <div className="space-y-1">
            <Label>Subjects</Label>
            <Input value={subInput} onChange={(e) => setSubInput(e.target.value)} placeholder="Math, Physics, Chemistry" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSubOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveSubjects}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Classes Dialog */}
      <Dialog open={classOpen} onOpenChange={setClassOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Classes</DialogTitle>
            <DialogDescription>Enter classes separated by commas.</DialogDescription>
          </DialogHeader>
          <div className="space-y-1">
            <Label>Classes</Label>
            <Input value={classInput} onChange={(e) => setClassInput(e.target.value)} placeholder="FE-A, SE-B, TE-C" />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setClassOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveClasses}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

const InfoRow = ({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) => (
  <div className="flex items-center gap-2 text-foreground">
    <span className="text-muted-foreground">{icon}</span>
    <span className="text-muted-foreground">{label}:</span>
    <span className="font-medium">{value}</span>
  </div>
);

export default TeacherDashboard;
