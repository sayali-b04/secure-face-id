import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  ArrowLeft, Save, User, GraduationCap, BookOpen, Plus, Trash2,
} from "lucide-react";

const API = "http://localhost:5000/api";
const YEARS = ["FE", "SE", "TE", "BE"] as const;
const getToken = () => localStorage.getItem("token") ?? "";

const authFetch = async (url: string, opts: RequestInit = {}) => {
  const res = await fetch(url, {
    ...opts,
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${getToken()}`, ...(opts.headers as Record<string, string>) },
  });
  if (!res.ok) throw new Error(await res.text());
  return res.json();
};

const ProfileEdit = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [role, setRole] = useState("");

  /* shared fields */
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [department, setDepartment] = useState("");
  const [imageUrl, setImageUrl] = useState("");

  /* student fields */
  const [rollNumber, setRollNumber] = useState("");
  const [year, setYear] = useState("");
  const [admissionYear, setAdmissionYear] = useState("");
  const [passoutYear, setPassoutYear] = useState("");
  const [marks, setMarks] = useState<{ year: string; subjects: string[]; gpa: number }[]>([]);

  /* teacher fields */
  const [joiningYear, setJoiningYear] = useState("");
  const [subjects, setSubjects] = useState<string[]>([]);
  const [classesHandled, setClassesHandled] = useState<string[]>([]);
  const [newSubject, setNewSubject] = useState("");
  const [newClass, setNewClass] = useState("");

  /* marks editing */
  const [marksYear, setMarksYear] = useState("FE");
  const [marksSubjects, setMarksSubjects] = useState("");
  const [marksGpa, setMarksGpa] = useState("");

  useEffect(() => {
    if (!getToken()) { navigate("/login"); return; }
    authFetch(`${API}/users/profile`)
      .then((data) => {
        setRole(data.role);
        setName(data.name ?? "");
        setEmail(data.email ?? "");
        setDepartment(data.department ?? "");
        setImageUrl(data.imageUrl ?? "");
        setRollNumber(data.rollNumber ?? "");
        setYear(data.year ?? "");
        setAdmissionYear(data.admissionYear?.toString() ?? "");
        setPassoutYear(data.passoutYear?.toString() ?? "");
        setMarks(data.marks ?? []);
        setJoiningYear(data.joiningYear?.toString() ?? "");
        setSubjects(data.subjects ?? []);
        setClassesHandled(data.classesHandled ?? []);
        setLoading(false);
      })
      .catch(() => { toast.error("Session expired"); navigate("/login"); });
  }, [navigate]);

  /* save general profile */
  const handleSave = async () => {
    setSaving(true);
    try {
      const body: Record<string, unknown> = { name, department };
      if (role === "student") {
        Object.assign(body, { rollNumber, year, admissionYear, passoutYear });
      } else {
        Object.assign(body, { joiningYear, subjects, classesHandled });
      }
      await authFetch(`${API}/users/profile`, { method: "PUT", body: JSON.stringify(body) });
      toast.success("Profile saved");
    } catch { toast.error("Failed to save"); }
    setSaving(false);
  };

  /* save marks for a year */
  const handleSaveMarks = async () => {
    try {
      const updated = await authFetch(`${API}/users/marks`, {
        method: "PUT",
        body: JSON.stringify({
          year: marksYear,
          subjects: marksSubjects.split(",").map((s) => s.trim()).filter(Boolean),
          gpa: parseFloat(marksGpa),
        }),
      });
      setMarks(updated.marks ?? []);
      toast.success("Marks saved");
    } catch { toast.error("Failed to save marks"); }
  };

  const addSubject = () => {
    if (newSubject.trim()) { setSubjects([...subjects, newSubject.trim()]); setNewSubject(""); }
  };
  const removeSubject = (i: number) => setSubjects(subjects.filter((_, idx) => idx !== i));

  const addClass = () => {
    if (newClass.trim()) { setClassesHandled([...classesHandled, newClass.trim()]); setNewClass(""); }
  };
  const removeClass = (i: number) => setClassesHandled(classesHandled.filter((_, idx) => idx !== i));

  const loadMarksForYear = (yr: string) => {
    setMarksYear(yr);
    const entry = marks.find((m) => m.year === yr);
    setMarksSubjects(entry?.subjects?.join(", ") ?? "");
    setMarksGpa(entry?.gpa?.toString() ?? "");
  };

  const goBack = () => {
    navigate(role === "student" ? "/student-dashboard" : "/teacher-dashboard");
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-muted-foreground">Loading…</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-3xl mx-auto space-y-6">

        {/* header */}
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={goBack}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Back
          </Button>
          <h1 className="text-2xl font-bold text-foreground">Edit Profile</h1>
          <Button size="sm" onClick={handleSave} disabled={saving}>
            <Save className="h-4 w-4 mr-1" /> {saving ? "Saving…" : "Save"}
          </Button>
        </div>

        {/* profile banner (LinkedIn style) */}
        <Card>
          <div className="h-24 bg-primary rounded-t-lg" />
          <CardContent className="relative pt-0 -mt-10 flex items-end gap-4 pb-6">
            <Avatar className="h-20 w-20 border-4 border-background">
              <AvatarImage src={imageUrl ? `${API.replace("/api", "")}/${imageUrl}` : undefined} />
              <AvatarFallback className="text-xl">{name?.charAt(0) ?? "U"}</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="text-xl font-bold text-foreground">{name || "Your Name"}</h2>
              <p className="text-sm text-muted-foreground">{email}</p>
              <Badge variant="secondary" className="mt-1 capitalize">{role}</Badge>
            </div>
          </CardContent>
        </Card>

        {/* basic info */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="h-5 w-5" /> Basic Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label="Name" value={name} onChange={setName} />
              <Field label="Department" value={department} onChange={setDepartment} />
            </div>
          </CardContent>
        </Card>

        {/* role-specific section */}
        {role === "student" ? (
          <>
            {/* academic info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <GraduationCap className="h-5 w-5" /> Academic Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field label="Roll Number" value={rollNumber} onChange={setRollNumber} />
                  <div className="space-y-1">
                    <Label>Year</Label>
                    <Select value={year} onValueChange={setYear}>
                      <SelectTrigger><SelectValue placeholder="Select year" /></SelectTrigger>
                      <SelectContent>
                        {YEARS.map((y) => <SelectItem key={y} value={y}>{y}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <Field label="Admission Year" value={admissionYear} onChange={setAdmissionYear} />
                  <Field label="Passout Year" value={passoutYear} onChange={setPassoutYear} placeholder="Leave empty for Currently Pursuing" />
                </div>
              </CardContent>
            </Card>

            {/* marks */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <BookOpen className="h-5 w-5" /> Marks
                </CardTitle>
                <CardDescription>Select a year tab, enter subjects and GPA, then save.</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="FE" onValueChange={loadMarksForYear}>
                  <TabsList className="grid grid-cols-4 w-full">
                    {YEARS.map((y) => <TabsTrigger key={y} value={y}>{y}</TabsTrigger>)}
                  </TabsList>
                  {YEARS.map((y) => {
                    const entry = marks.find((m) => m.year === y);
                    return (
                      <TabsContent key={y} value={y} className="space-y-4 pt-2">
                        {entry && (
                          <Table>
                            <TableHeader><TableRow><TableHead>Current Subjects</TableHead></TableRow></TableHeader>
                            <TableBody>
                              {entry.subjects.map((s, i) => <TableRow key={i}><TableCell>{s}</TableCell></TableRow>)}
                            </TableBody>
                          </Table>
                        )}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <Label>Subjects (comma separated)</Label>
                            <Input value={marksYear === y ? marksSubjects : ""} onChange={(e) => { setMarksYear(y); setMarksSubjects(e.target.value); }} placeholder="Maths, Physics" />
                          </div>
                          <div className="space-y-1">
                            <Label>GPA</Label>
                            <Input value={marksYear === y ? marksGpa : ""} onChange={(e) => { setMarksYear(y); setMarksGpa(e.target.value); }} placeholder="e.g. 8.5" />
                          </div>
                        </div>
                        <Button size="sm" onClick={handleSaveMarks}>
                          <Save className="h-4 w-4 mr-1" /> Save Marks for {y}
                        </Button>
                      </TabsContent>
                    );
                  })}
                </Tabs>
              </CardContent>
            </Card>
          </>
        ) : (
          <>
            {/* teacher info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <GraduationCap className="h-5 w-5" /> Teaching Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Field label="Joining Year" value={joiningYear} onChange={setJoiningYear} />

                <Separator />

                {/* subjects */}
                <div>
                  <Label className="text-base font-semibold">Subjects</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {subjects.map((s, i) => (
                      <Badge key={i} variant="secondary" className="gap-1">
                        {s}
                        <button onClick={() => removeSubject(i)} className="ml-1 hover:text-destructive"><Trash2 className="h-3 w-3" /></button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-2">
                    <Input value={newSubject} onChange={(e) => setNewSubject(e.target.value)} placeholder="Add subject" className="max-w-xs" onKeyDown={(e) => e.key === "Enter" && addSubject()} />
                    <Button size="sm" variant="outline" onClick={addSubject}><Plus className="h-4 w-4" /></Button>
                  </div>
                </div>

                <Separator />

                {/* classes */}
                <div>
                  <Label className="text-base font-semibold">Classes Handled</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {classesHandled.map((c, i) => (
                      <Badge key={i} variant="outline" className="gap-1">
                        {c}
                        <button onClick={() => removeClass(i)} className="ml-1 hover:text-destructive"><Trash2 className="h-3 w-3" /></button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-2">
                    <Input value={newClass} onChange={(e) => setNewClass(e.target.value)} placeholder="Add class (e.g. FE-A)" className="max-w-xs" onKeyDown={(e) => e.key === "Enter" && addClass()} />
                    <Button size="sm" variant="outline" onClick={addClass}><Plus className="h-4 w-4" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
};

const Field = ({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) => (
  <div className="space-y-1">
    <Label>{label}</Label>
    <Input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} />
  </div>
);

export default ProfileEdit;
