/**
 * Login Page
 * ----------
 * Email + Password + Face Verification (liveness required).
 * Cannot submit without passing face detection.
 */

import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import FaceDetector from "@/components/FaceDetector";
import { LogIn } from "lucide-react";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [faceVerified, setFaceVerified] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFaceVerified = () => {
    setFaceVerified(true);
    toast({
      title: "Face Verified ✅",
      description: "Liveness confirmed. You may now log in.",
    });
  };

  const handleFaceError = (message: string) => {
    toast({
      title: "Only real human face is allowed",
      description: message,
      variant: "destructive",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !password) {
      toast({ title: "Missing Fields", description: "Please enter email and password.", variant: "destructive" });
      return;
    }

    if (!faceVerified) {
      toast({
        title: "Only real human face is allowed",
        description: "You must complete face verification before logging in.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    // Mock login
    setTimeout(() => {
      toast({ title: "Login Successful! 🎉", description: "Welcome back!" });
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl flex items-center justify-center gap-2">
            <LogIn className="h-6 w-6" />
            Login
          </CardTitle>
          <CardDescription>
            Verify your identity with face detection
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div className="space-y-1">
              <Label htmlFor="login-email">Email</Label>
              <Input
                id="login-email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            {/* Password */}
            <div className="space-y-1">
              <Label htmlFor="login-password">Password</Label>
              <Input
                id="login-password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {/* Face Detection */}
            <div className="space-y-1">
              <Label>Face Verification (Required)</Label>
              <FaceDetector onVerified={handleFaceVerified} onError={handleFaceError} />
              {faceVerified && (
                <p className="text-xs text-success mt-1">✅ Face verified</p>
              )}
            </div>

            {/* Submit */}
            <Button type="submit" className="w-full" disabled={isSubmitting || !faceVerified}>
              {isSubmitting ? "Logging in..." : "Login"}
            </Button>

            <p className="text-sm text-center text-muted-foreground">
              Don't have an account?{" "}
              <Link to="/register" className="text-primary underline">
                Register
              </Link>
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;
