/**
 * Registration Page
 * -----------------
 * Fields: Name, Email, Password, Role (Student/Teacher), Face Verification.
 * User MUST pass face liveness detection before submitting.
 */

import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/hooks/use-toast";
import FaceDetector from "@/components/FaceDetector";
import { UserPlus } from "lucide-react";

const Register = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<string>("");
  const [department, setDepartment] = useState("");
  const [rollNumber, setRollNumber] = useState("");
  const [year, setYear] = useState("");
  const [admissionYear, setAdmissionYear] = useState("");
  const [passoutYear, setPassoutYear] = useState("");
  const [currentlyPursuing, setCurrentlyPursuing] = useState(false);
  const [joiningYear, setJoiningYear] = useState("");
  const [faceImage, setFaceImage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Called when face liveness is verified
  const handleFaceVerified = (capturedImage: string) => {
    setFaceImage(capturedImage);
    toast({
      title: "Face Verified ✅",
      description: "Your face has been successfully verified.",
    });
  };

  const handleFaceError = (message: string) => {
    toast({
      title: "Only real human face is allowed",
      description: message,
      variant: "destructive",
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate all fields
    if (!name || !email || !password || !role) {
      toast({ title: "Missing Fields", description: "Please fill all required fields.", variant: "destructive" });
      return;
    }

    // Face verification is mandatory
    if (!faceImage) {
      toast({
        title: "Only real human face is allowed",
        description: "You must complete face verification before registering.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    // Mock registration (no real backend in this Lovable project)
    setTimeout(() => {
      toast({
        title: "Registration Successful! 🎉",
        description: `Welcome ${name}! Your account has been created as ${role}.`,
      });
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl flex items-center justify-center gap-2">
            <UserPlus className="h-6 w-6" />
            Register
          </CardTitle>
          <CardDescription>
            Blockchain-based AI Face Identity Verification
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Name */}
            <div className="space-y-1">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                placeholder="Enter your full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            {/* Email */}
            <div className="space-y-1">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            {/* Password */}
            <div className="space-y-1">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Create a strong password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {/* Role */}
            <div className="space-y-1">
              <Label>Role</Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student">Student</SelectItem>
                  <SelectItem value="teacher">Teacher</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Student-specific fields */}
            {role === "student" && (
              <>
                <div className="space-y-1">
                  <Label htmlFor="department">Department</Label>
                  <Input id="department" placeholder="e.g. Computer Science" value={department} onChange={(e) => setDepartment(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="rollNumber">Roll Number</Label>
                  <Input id="rollNumber" placeholder="e.g. CS2023001" value={rollNumber} onChange={(e) => setRollNumber(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label>Year</Label>
                  <Select value={year} onValueChange={setYear}>
                    <SelectTrigger><SelectValue placeholder="Select year" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="FE">FE</SelectItem>
                      <SelectItem value="SE">SE</SelectItem>
                      <SelectItem value="TE">TE</SelectItem>
                      <SelectItem value="BE">BE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="admissionYear">Admission Year</Label>
                  <Input id="admissionYear" type="number" placeholder="e.g. 2023" value={admissionYear} onChange={(e) => setAdmissionYear(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="passoutYear">Passout Year</Label>
                  <div className="flex items-center gap-3">
                    <Input id="passoutYear" type="number" placeholder="e.g. 2027" value={currentlyPursuing ? "" : passoutYear} onChange={(e) => setPassoutYear(e.target.value)} disabled={currentlyPursuing} className="flex-1" />
                    <div className="flex items-center gap-1.5">
                      <Checkbox id="currentlyPursuing" checked={currentlyPursuing} onCheckedChange={(v) => { setCurrentlyPursuing(!!v); if (v) setPassoutYear(""); }} />
                      <Label htmlFor="currentlyPursuing" className="text-xs whitespace-nowrap">Currently Pursuing</Label>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Teacher-specific fields */}
            {role === "teacher" && (
              <>
                <div className="space-y-1">
                  <Label htmlFor="tDepartment">Department</Label>
                  <Input id="tDepartment" placeholder="e.g. Computer Science" value={department} onChange={(e) => setDepartment(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="joiningYear">Joining Year</Label>
                  <Input id="joiningYear" type="number" placeholder="e.g. 2015" value={joiningYear} onChange={(e) => setJoiningYear(e.target.value)} />
                </div>
              </>
            )}

            {/* Face Detection / Liveness Verification */}
            <div className="space-y-1">
              <Label>Face Verification (Required)</Label>
              <FaceDetector onVerified={handleFaceVerified} onError={handleFaceError} />
              {faceImage && (
                <p className="text-xs text-success mt-1">✅ Face captured and verified</p>
              )}
            </div>

            {/* Submit */}
            <Button type="submit" className="w-full" disabled={isSubmitting || !faceImage}>
              {isSubmitting ? "Registering..." : "Register"}
            </Button>

            <p className="text-sm text-center text-muted-foreground">
              Already have an account?{" "}
              <Link to="/login" className="text-primary underline">
                Login
              </Link>
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Register;
