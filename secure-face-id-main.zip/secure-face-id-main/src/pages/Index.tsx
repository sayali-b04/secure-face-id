import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScanFace, UserPlus, LogIn } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-lg text-center">
        <CardHeader>
          <div className="flex justify-center mb-2">
            <ScanFace className="h-12 w-12 text-primary" />
          </div>
          <CardTitle className="text-2xl">AI Face Identity Verification</CardTitle>
          <CardDescription>
            Blockchain-based identity system with real-time face detection &amp; liveness verification
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-3 sm:flex-row sm:justify-center">
          <Button asChild size="lg">
            <Link to="/register">
              <UserPlus className="h-4 w-4 mr-2" /> Register
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link to="/login">
              <LogIn className="h-4 w-4 mr-2" /> Login
            </Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default Index;
